from flask import Flask, request, jsonify
from flask_cors import CORS
import os

app = Flask(__name__)  # Corrected _name to __name__
CORS(app)

UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/submit', methods=['POST'])
def submit():
    try:
        name = request.form.get('name')
        age = request.form.get('age')
        file = request.files.get('file')

        if file:
            filename = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filename)

        # Here you can add database operations or other processing

        return jsonify({
            'status': 'success',
            'message': 'Data received successfully',
            'data': {
                'name': name,
                'age': age,
                'filename': file.filename if file else None
            }
        }), 200

    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

if __name__ == '__main__':  # Corrected _name to __name__ and main to __main__
    app.run(debug=True)
    